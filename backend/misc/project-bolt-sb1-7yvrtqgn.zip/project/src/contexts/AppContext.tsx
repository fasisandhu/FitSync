import React, { createContext, useContext, useEffect, useState } from 'react';
import { Member, Trainer, SubscriptionPlan, MemberSubscription, Payment, AttendanceRecord, DashboardStats } from '../types';

interface AppContextType {
  // Members
  members: Member[];
  addMember: (member: Omit<Member, 'id'>) => void;
  updateMember: (id: string, member: Partial<Member>) => void;
  deleteMember: (id: string) => void;
  
  // Trainers
  trainers: Trainer[];
  addTrainer: (trainer: Omit<Trainer, 'id'>) => void;
  updateTrainer: (id: string, trainer: Partial<Trainer>) => void;
  deleteTrainer: (id: string) => void;
  
  // Subscription Plans
  subscriptionPlans: SubscriptionPlan[];
  addSubscriptionPlan: (plan: Omit<SubscriptionPlan, 'id'>) => void;
  updateSubscriptionPlan: (id: string, plan: Partial<SubscriptionPlan>) => void;
  deleteSubscriptionPlan: (id: string) => void;
  
  // Member Subscriptions
  memberSubscriptions: MemberSubscription[];
  addMemberSubscription: (subscription: Omit<MemberSubscription, 'id'>) => void;
  updateMemberSubscription: (id: string, subscription: Partial<MemberSubscription>) => void;
  
  // Payments
  payments: Payment[];
  addPayment: (payment: Omit<Payment, 'id'>) => void;
  updatePayment: (id: string, payment: Partial<Payment>) => void;
  
  // Attendance
  attendanceRecords: AttendanceRecord[];
  checkIn: (memberId: string) => void;
  checkOut: (memberId: string) => void;
  
  // Dashboard
  dashboardStats: DashboardStats;
  
  // Loading
  isLoading: boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [members, setMembers] = useState<Member[]>([]);
  const [trainers, setTrainers] = useState<Trainer[]>([]);
  const [subscriptionPlans, setSubscriptionPlans] = useState<SubscriptionPlan[]>([]);
  const [memberSubscriptions, setMemberSubscriptions] = useState<MemberSubscription[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Initialize with mock data
    initializeMockData();
  }, []);

  const initializeMockData = () => {
    // Mock Members
    const mockMembers: Member[] = [
      {
        id: '1',
        name: 'Sarah Johnson',
        email: 'sarah@example.com',
        phone: '+1234567890',
        gender: 'female',
        dateOfBirth: '1990-05-15',
        address: '123 Main St, City',
        dateOfJoining: '2024-01-15',
        isActive: true,
        assignedTrainer: '1',
        emergencyContact: {
          name: 'John Johnson',
          phone: '+1234567891',
          relationship: 'Spouse'
        },
        avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?w=150',
        subscriptionStatus: 'active'
      },
      {
        id: '2',
        name: 'Mike Chen',
        email: 'mike@example.com',
        phone: '+1234567892',
        gender: 'male',
        dateOfBirth: '1985-08-22',
        address: '456 Oak Ave, City',
        dateOfJoining: '2024-02-01',
        isActive: true,
        assignedTrainer: '2',
        emergencyContact: {
          name: 'Lisa Chen',
          phone: '+1234567893',
          relationship: 'Sister'
        },
        avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?w=150',
        subscriptionStatus: 'active'
      }
    ];

    // Mock Trainers
    const mockTrainers: Trainer[] = [
      {
        id: '1',
        name: 'Alex Rodriguez',
        email: 'alex@gym.com',
        phone: '+1234567894',
        specialization: ['Weight Training', 'HIIT', 'Nutrition'],
        experience: 5,
        certifications: ['NASM-CPT', 'Nutrition Specialist'],
        isActive: true,
        avatar: 'https://images.pexels.com/photos/1431282/pexels-photo-1431282.jpeg?w=150',
        assignedMembers: ['1'],
        workloadScore: 75
      },
      {
        id: '2',
        name: 'Emma Williams',
        email: 'emma@gym.com',
        phone: '+1234567895',
        specialization: ['Yoga', 'Pilates', 'Flexibility'],
        experience: 3,
        certifications: ['RYT-200', 'Pilates Instructor'],
        isActive: true,
        avatar: 'https://images.pexels.com/photos/3768916/pexels-photo-3768916.jpeg?w=150',
        assignedMembers: ['2'],
        workloadScore: 60
      }
    ];

    // Mock Subscription Plans
    const mockPlans: SubscriptionPlan[] = [
      {
        id: '1',
        name: 'Basic Plan',
        duration: 1,
        price: 50,
        features: ['Gym Access', 'Basic Equipment', 'Locker'],
        isActive: true,
        planType: 'basic'
      },
      {
        id: '2',
        name: 'Premium Plan',
        duration: 3,
        price: 120,
        features: ['Gym Access', 'Personal Training', 'Nutrition Consultation', 'Group Classes'],
        isActive: true,
        planType: 'premium'
      },
      {
        id: '3',
        name: 'Elite Plan',
        duration: 12,
        price: 400,
        features: ['All Premium Features', '24/7 Access', 'Spa Access', 'Meal Planning'],
        isActive: true,
        planType: 'elite'
      }
    ];

    setMembers(mockMembers);
    setTrainers(mockTrainers);
    setSubscriptionPlans(mockPlans);
    setIsLoading(false);
  };

  // Member functions
  const addMember = (member: Omit<Member, 'id'>) => {
    const newMember = { ...member, id: Date.now().toString() };
    setMembers(prev => [...prev, newMember]);
  };

  const updateMember = (id: string, memberUpdate: Partial<Member>) => {
    setMembers(prev => prev.map(member => 
      member.id === id ? { ...member, ...memberUpdate } : member
    ));
  };

  const deleteMember = (id: string) => {
    setMembers(prev => prev.filter(member => member.id !== id));
  };

  // Trainer functions
  const addTrainer = (trainer: Omit<Trainer, 'id'>) => {
    const newTrainer = { ...trainer, id: Date.now().toString() };
    setTrainers(prev => [...prev, newTrainer]);
  };

  const updateTrainer = (id: string, trainerUpdate: Partial<Trainer>) => {
    setTrainers(prev => prev.map(trainer => 
      trainer.id === id ? { ...trainer, ...trainerUpdate } : trainer
    ));
  };

  const deleteTrainer = (id: string) => {
    setTrainers(prev => prev.filter(trainer => trainer.id !== id));
  };

  // Subscription Plan functions
  const addSubscriptionPlan = (plan: Omit<SubscriptionPlan, 'id'>) => {
    const newPlan = { ...plan, id: Date.now().toString() };
    setSubscriptionPlans(prev => [...prev, newPlan]);
  };

  const updateSubscriptionPlan = (id: string, planUpdate: Partial<SubscriptionPlan>) => {
    setSubscriptionPlans(prev => prev.map(plan => 
      plan.id === id ? { ...plan, ...planUpdate } : plan
    ));
  };

  const deleteSubscriptionPlan = (id: string) => {
    setSubscriptionPlans(prev => prev.filter(plan => plan.id !== id));
  };

  // Member Subscription functions
  const addMemberSubscription = (subscription: Omit<MemberSubscription, 'id'>) => {
    const newSubscription = { ...subscription, id: Date.now().toString() };
    setMemberSubscriptions(prev => [...prev, newSubscription]);
  };

  const updateMemberSubscription = (id: string, subscriptionUpdate: Partial<MemberSubscription>) => {
    setMemberSubscriptions(prev => prev.map(subscription => 
      subscription.id === id ? { ...subscription, ...subscriptionUpdate } : subscription
    ));
  };

  // Payment functions
  const addPayment = (payment: Omit<Payment, 'id'>) => {
    const newPayment = { ...payment, id: Date.now().toString() };
    setPayments(prev => [...prev, newPayment]);
  };

  const updatePayment = (id: string, paymentUpdate: Partial<Payment>) => {
    setPayments(prev => prev.map(payment => 
      payment.id === id ? { ...payment, ...paymentUpdate } : payment
    ));
  };

  // Attendance functions
  const checkIn = (memberId: string) => {
    const newRecord: AttendanceRecord = {
      id: Date.now().toString(),
      memberId,
      checkIn: new Date().toISOString(),
      date: new Date().toISOString().split('T')[0]
    };
    setAttendanceRecords(prev => [...prev, newRecord]);
  };

  const checkOut = (memberId: string) => {
    const now = new Date().toISOString();
    setAttendanceRecords(prev => prev.map(record => {
      if (record.memberId === memberId && !record.checkOut && 
          record.date === new Date().toISOString().split('T')[0]) {
        const checkInTime = new Date(record.checkIn);
        const checkOutTime = new Date(now);
        const duration = Math.floor((checkOutTime.getTime() - checkInTime.getTime()) / (1000 * 60));
        return { ...record, checkOut: now, duration };
      }
      return record;
    }));
  };

  // Dashboard stats
  const dashboardStats: DashboardStats = {
    totalMembers: members.length,
    activeMembers: members.filter(m => m.isActive).length,
    totalTrainers: trainers.length,
    todayAttendance: attendanceRecords.filter(r => 
      r.date === new Date().toISOString().split('T')[0]
    ).length,
    monthlyRevenue: payments.reduce((sum, p) => sum + p.amount, 0),
    pendingPayments: payments.filter(p => p.status === 'pending').length
  };

  const value = {
    members,
    addMember,
    updateMember,
    deleteMember,
    trainers,
    addTrainer,
    updateTrainer,
    deleteTrainer,
    subscriptionPlans,
    addSubscriptionPlan,
    updateSubscriptionPlan,
    deleteSubscriptionPlan,
    memberSubscriptions,
    addMemberSubscription,
    updateMemberSubscription,
    payments,
    addPayment,
    updatePayment,
    attendanceRecords,
    checkIn,
    checkOut,
    dashboardStats,
    isLoading
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};