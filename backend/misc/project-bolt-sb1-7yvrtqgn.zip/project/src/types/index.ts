export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'trainer' | 'member';
  avatar?: string;
}

export interface Member {
  id: string;
  name: string;
  email: string;
  phone: string;
  gender: 'male' | 'female' | 'other';
  dateOfBirth: string;
  address: string;
  dateOfJoining: string;
  isActive: boolean;
  assignedTrainer?: string;
  emergencyContact: {
    name: string;
    phone: string;
    relationship: string;
  };
  avatar?: string;
  subscriptionStatus: 'active' | 'expired' | 'pending';
}

export interface Trainer {
  id: string;
  name: string;
  email: string;
  phone: string;
  specialization: string[];
  experience: number;
  certifications: string[];
  isActive: boolean;
  avatar?: string;
  assignedMembers: string[];
  workloadScore: number;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  duration: number; // in months
  price: number;
  features: string[];
  isActive: boolean;
  planType: 'basic' | 'premium' | 'elite';
}

export interface MemberSubscription {
  id: string;
  memberId: string;
  planId: string;
  startDate: string;
  endDate: string;
  status: 'active' | 'expired' | 'suspended';
  autoRenew: boolean;
}

export interface Payment {
  id: string;
  memberId: string;
  amount: number;
  paymentDate: string;
  dueDate: string;
  status: 'paid' | 'pending' | 'overdue';
  paymentMethod: 'cash' | 'card' | 'upi' | 'bank_transfer';
  subscriptionId: string;
  invoiceNumber: string;
}

export interface AttendanceRecord {
  id: string;
  memberId: string;
  checkIn: string;
  checkOut?: string;
  date: string;
  duration?: number; // in minutes
}

export interface DashboardStats {
  totalMembers: number;
  activeMembers: number;
  totalTrainers: number;
  todayAttendance: number;
  monthlyRevenue: number;
  pendingPayments: number;
}