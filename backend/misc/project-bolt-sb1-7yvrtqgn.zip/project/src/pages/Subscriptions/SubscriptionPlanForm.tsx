import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Plus, X } from 'lucide-react';
import Button from '../../components/UI/Button';
import { useApp } from '../../contexts/AppContext';
import { SubscriptionPlan } from '../../types';

const planSchema = z.object({
  name: z.string().min(1, 'Plan name is required'),
  duration: z.number().min(1, 'Duration must be at least 1 month'),
  price: z.number().min(0, 'Price must be a positive number'),
  planType: z.enum(['basic', 'premium', 'elite']),
  isActive: z.boolean(),
});

type PlanFormData = z.infer<typeof planSchema>;

interface SubscriptionPlanFormProps {
  plan?: SubscriptionPlan | null;
  onSuccess: () => void;
  onCancel: () => void;
}

const SubscriptionPlanForm: React.FC<SubscriptionPlanFormProps> = ({ plan, onSuccess, onCancel }) => {
  const { addSubscriptionPlan, updateSubscriptionPlan } = useApp();
  const isEditing = !!plan;

  const [features, setFeatures] = React.useState<string[]>(
    plan?.features || []
  );
  const [newFeature, setNewFeature] = React.useState('');

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<PlanFormData>({
    resolver: zodResolver(planSchema),
    defaultValues: plan ? {
      name: plan.name,
      duration: plan.duration,
      price: plan.price,
      planType: plan.planType,
      isActive: plan.isActive,
    } : {
      isActive: true,
      duration: 1,
      price: 0,
      planType: 'basic',
    }
  });

  const addFeature = () => {
    if (newFeature.trim() && !features.includes(newFeature.trim())) {
      setFeatures([...features, newFeature.trim()]);
      setNewFeature('');
    }
  };

  const removeFeature = (index: number) => {
    setFeatures(features.filter((_, i) => i !== index));
  };

  const onSubmit = async (data: PlanFormData) => {
    try {
      const planData = {
        name: data.name,
        duration: data.duration,
        price: data.price,
        planType: data.planType,
        isActive: data.isActive,
        features: features,
      };

      if (isEditing && plan) {
        updateSubscriptionPlan(plan.id, planData);
      } else {
        addSubscriptionPlan(planData);
      }

      onSuccess();
    } catch (error) {
      console.error('Error saving plan:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Basic Information */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-gray-900">Plan Details</h3>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Plan Name *
            </label>
            <input
              {...register('name')}
              type="text"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter plan name"
            />
            {errors.name && (
              <p className="text-red-600 text-sm mt-1">{errors.name.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Plan Type *
            </label>
            <select
              {...register('planType')}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="basic">Basic</option>
              <option value="premium">Premium</option>
              <option value="elite">Elite</option>
            </select>
            {errors.planType && (
              <p className="text-red-600 text-sm mt-1">{errors.planType.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Duration (Months) *
            </label>
            <input
              {...register('duration', { valueAsNumber: true })}
              type="number"
              min="1"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter duration in months"
            />
            {errors.duration && (
              <p className="text-red-600 text-sm mt-1">{errors.duration.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Price ($) *
            </label>
            <input
              {...register('price', { valueAsNumber: true })}
              type="number"
              min="0"
              step="0.01"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter price"
            />
            {errors.price && (
              <p className="text-red-600 text-sm mt-1">{errors.price.message}</p>
            )}
          </div>

          <div className="flex items-center">
            <input
              {...register('isActive')}
              type="checkbox"
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
            />
            <label className="ml-2 block text-sm text-gray-700">
              Active Plan
            </label>
          </div>
        </div>

        {/* Features */}
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-gray-900">Plan Features</h3>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Add Features
            </label>
            <div className="flex space-x-2 mb-2">
              <input
                type="text"
                value={newFeature}
                onChange={(e) => setNewFeature(e.target.value)}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Add a feature"
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addFeature())}
              />
              <Button
                type="button"
                variant="secondary"
                size="sm"
                icon={Plus}
                onClick={addFeature}
              >
                Add
              </Button>
            </div>
            
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {features.map((feature, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                >
                  <span className="text-sm text-gray-700">{feature}</span>
                  <button
                    type="button"
                    onClick={() => removeFeature(index)}
                    className="text-red-600 hover:text-red-800"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
            
            {features.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <p>No features added yet</p>
                <p className="text-sm">Add features to describe what's included in this plan</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Preview */}
      <div className="border-t pt-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Plan Preview</h3>
        <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg p-6 border border-blue-200">
          <div className="text-center mb-4">
            <h4 className="text-xl font-bold text-gray-900">{register('name').name || 'Plan Name'}</h4>
            <div className="flex items-center justify-center space-x-1 mt-2">
              <span className="text-2xl font-bold text-blue-600">$</span>
              <span className="text-2xl font-bold text-blue-600">{register('price').name || '0'}</span>
              <span className="text-gray-500">/ month</span>
            </div>
          </div>
          <div className="space-y-2">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-sm text-gray-600">{feature}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Form Actions */}
      <div className="flex justify-end space-x-3 pt-6 border-t">
        <Button
          type="button"
          variant="secondary"
          onClick={onCancel}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          disabled={isSubmitting}
        >
          {isSubmitting ? 'Saving...' : isEditing ? 'Update Plan' : 'Create Plan'}
        </Button>
      </div>
    </form>
  );
};

export default SubscriptionPlanForm;