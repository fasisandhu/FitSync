import React, { useState } from 'react';
import { Plus, Search, Filter, Calendar, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import Card from '../../components/UI/Card';
import Button from '../../components/UI/Button';
import Badge from '../../components/UI/Badge';
import Modal from '../../components/UI/Modal';
import { useApp } from '../../contexts/AppContext';
import { format, parseISO, isAfter, isBefore, addDays } from 'date-fns';
import AssignSubscriptionForm from './AssignSubscriptionForm';

const MemberSubscriptions = () => {
  const { members, subscriptionPlans, memberSubscriptions, addMemberSubscription } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'expired' | 'expiring'>('all');
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);

  // Create mock member subscriptions for demonstration
  const mockMemberSubscriptions = members.map(member => {
    const plan = subscriptionPlans[Math.floor(Math.random() * subscriptionPlans.length)];
    const startDate = new Date();
    startDate.setMonth(startDate.getMonth() - Math.floor(Math.random() * 6));
    const endDate = new Date(startDate);
    endDate.setMonth(endDate.getMonth() + plan.duration);
    
    const now = new Date();
    const isExpired = isAfter(now, endDate);
    const isExpiringSoon = !isExpired && isBefore(now, addDays(endDate, -7));
    
    return {
      id: `sub-${member.id}`,
      memberId: member.id,
      planId: plan.id,
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      status: isExpired ? 'expired' : 'active',
      autoRenew: Math.random() > 0.5,
      member,
      plan,
      isExpiringSoon
    };
  });

  const filteredSubscriptions = mockMemberSubscriptions.filter(subscription => {
    const matchesSearch = subscription.member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         subscription.member.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         subscription.plan.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    let matchesFilter = true;
    switch (filterStatus) {
      case 'active':
        matchesFilter = subscription.status === 'active';
        break;
      case 'expired':
        matchesFilter = subscription.status === 'expired';
        break;
      case 'expiring':
        matchesFilter = subscription.isExpiringSoon;
        break;
    }
    
    return matchesSearch && matchesFilter;
  });

  const getStatusBadge = (subscription: any) => {
    if (subscription.status === 'expired') {
      return <Badge variant="danger">Expired</Badge>;
    }
    if (subscription.isExpiringSoon) {
      return <Badge variant="warning">Expiring Soon</Badge>;
    }
    return <Badge variant="success">Active</Badge>;
  };

  const getDaysUntilExpiry = (endDate: string) => {
    const end = parseISO(endDate);
    const now = new Date();
    const diffTime = end.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Active Subscriptions</p>
              <p className="text-2xl font-bold text-gray-900">
                {mockMemberSubscriptions.filter(s => s.status === 'active').length}
              </p>
            </div>
            <div className="p-3 bg-green-100 rounded-lg">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Expiring Soon</p>
              <p className="text-2xl font-bold text-gray-900">
                {mockMemberSubscriptions.filter(s => s.isExpiringSoon).length}
              </p>
            </div>
            <div className="p-3 bg-yellow-100 rounded-lg">
              <AlertTriangle className="h-6 w-6 text-yellow-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Expired</p>
              <p className="text-2xl font-bold text-gray-900">
                {mockMemberSubscriptions.filter(s => s.status === 'expired').length}
              </p>
            </div>
            <div className="p-3 bg-red-100 rounded-lg">
              <Clock className="h-6 w-6 text-red-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Auto-Renewal</p>
              <p className="text-2xl font-bold text-gray-900">
                {mockMemberSubscriptions.filter(s => s.autoRenew).length}
              </p>
            </div>
            <div className="p-3 bg-blue-100 rounded-lg">
              <Calendar className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="text"
              placeholder="Search subscriptions..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Subscriptions</option>
              <option value="active">Active</option>
              <option value="expiring">Expiring Soon</option>
              <option value="expired">Expired</option>
            </select>
          </div>
          <Button
            icon={Plus}
            onClick={() => setIsAssignModalOpen(true)}
          >
            Assign Plan
          </Button>
        </div>
      </Card>

      {/* Subscriptions List */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-900">Member</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Plan</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Start Date</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">End Date</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Status</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Auto-Renew</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredSubscriptions.map((subscription) => {
                const daysUntilExpiry = getDaysUntilExpiry(subscription.endDate);
                
                return (
                  <tr key={subscription.id} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-4 px-4">
                      <div className="flex items-center space-x-3">
                        <img
                          src={subscription.member.avatar || 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?w=50'}
                          alt={subscription.member.name}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                        <div>
                          <p className="font-medium text-gray-900">{subscription.member.name}</p>
                          <p className="text-sm text-gray-500">{subscription.member.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      <div>
                        <p className="font-medium text-gray-900">{subscription.plan.name}</p>
                        <p className="text-sm text-gray-500">${subscription.plan.price}</p>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-gray-900">
                      {format(parseISO(subscription.startDate), 'MMM dd, yyyy')}
                    </td>
                    <td className="py-4 px-4">
                      <div>
                        <p className="text-gray-900">{format(parseISO(subscription.endDate), 'MMM dd, yyyy')}</p>
                        {subscription.status === 'active' && (
                          <p className="text-sm text-gray-500">
                            {daysUntilExpiry > 0 ? `${daysUntilExpiry} days left` : 'Expired'}
                          </p>
                        )}
                      </div>
                    </td>
                    <td className="py-4 px-4">
                      {getStatusBadge(subscription)}
                    </td>
                    <td className="py-4 px-4">
                      <Badge variant={subscription.autoRenew ? 'success' : 'gray'} size="sm">
                        {subscription.autoRenew ? 'Yes' : 'No'}
                      </Badge>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="secondary">
                          Renew
                        </Button>
                        <Button size="sm" variant="secondary">
                          Edit
                        </Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Assign Subscription Modal */}
      <Modal
        isOpen={isAssignModalOpen}
        onClose={() => setIsAssignModalOpen(false)}
        title="Assign Subscription Plan"
        size="lg"
      >
        <AssignSubscriptionForm
          onSuccess={() => {
            setIsAssignModalOpen(false);
          }}
          onCancel={() => setIsAssignModalOpen(false)}
        />
      </Modal>
    </div>
  );
};

export default MemberSubscriptions;