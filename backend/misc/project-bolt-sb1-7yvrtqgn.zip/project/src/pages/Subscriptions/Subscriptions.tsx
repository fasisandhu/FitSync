import React, { useState } from 'react';
import { Plus, Search, Filter, Eye, Edit, Trash2, FileText, Calendar, DollarSign } from 'lucide-react';
import Card from '../../components/UI/Card';
import Button from '../../components/UI/Button';
import Badge from '../../components/UI/Badge';
import Modal from '../../components/UI/Modal';
import { useApp } from '../../contexts/AppContext';
import { SubscriptionPlan } from '../../types';
import SubscriptionPlanForm from './SubscriptionPlanForm';
import MemberSubscriptions from './MemberSubscriptions';

const Subscriptions = () => {
  const { subscriptionPlans, deleteSubscriptionPlan } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'basic' | 'premium' | 'elite'>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isMemberSubscriptionsOpen, setIsMemberSubscriptionsOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);
  const [activeTab, setActiveTab] = useState<'plans' | 'members'>('plans');

  const filteredPlans = subscriptionPlans.filter(plan => {
    const matchesSearch = plan.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         plan.features.some(feature => feature.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesFilter = filterType === 'all' || plan.planType === filterType;
    return matchesSearch && matchesFilter && plan.isActive;
  });

  const handleEdit = (plan: SubscriptionPlan) => {
    setSelectedPlan(plan);
    setIsEditModalOpen(true);
  };

  const handleDelete = (plan: SubscriptionPlan) => {
    if (window.confirm(`Are you sure you want to delete ${plan.name}?`)) {
      deleteSubscriptionPlan(plan.id);
    }
  };

  const getPlanTypeColor = (type: string) => {
    switch (type) {
      case 'basic':
        return 'bg-blue-100 text-blue-800';
      case 'premium':
        return 'bg-purple-100 text-purple-800';
      case 'elite':
        return 'bg-gold-100 text-gold-800 bg-gradient-to-r from-yellow-100 to-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getDurationText = (months: number) => {
    if (months === 1) return '1 Month';
    if (months === 3) return '3 Months';
    if (months === 6) return '6 Months';
    if (months === 12) return '1 Year';
    return `${months} Months`;
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Subscriptions</h1>
          <p className="text-gray-600">Manage subscription plans and member subscriptions</p>
        </div>
        <Button
          icon={Plus}
          onClick={() => setIsAddModalOpen(true)}
        >
          Add Plan
        </Button>
      </div>

      {/* Tabs */}
      <Card>
        <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg">
          {[
            { key: 'plans', label: 'Subscription Plans', icon: FileText },
            { key: 'members', label: 'Member Subscriptions', icon: Calendar }
          ].map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setActiveTab(key as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors ${
                activeTab === key
                  ? 'bg-white text-blue-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{label}</span>
            </button>
          ))}
        </div>
      </Card>

      {activeTab === 'plans' && (
        <>
          {/* Filters */}
          <Card>
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <input
                  type="text"
                  placeholder="Search plans..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-gray-400" />
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value as any)}
                  className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="all">All Plans</option>
                  <option value="basic">Basic</option>
                  <option value="premium">Premium</option>
                  <option value="elite">Elite</option>
                </select>
              </div>
            </div>
          </Card>

          {/* Plans Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPlans.map((plan) => (
              <Card key={plan.id} className="hover:shadow-lg transition-shadow duration-200 relative overflow-hidden">
                {plan.planType === 'elite' && (
                  <div className="absolute top-0 right-0 bg-gradient-to-l from-yellow-400 to-orange-400 text-white px-3 py-1 text-xs font-medium">
                    POPULAR
                  </div>
                )}
                
                <div className="text-center mb-6">
                  <div className={`inline-flex px-3 py-1 rounded-full text-sm font-medium mb-3 ${getPlanTypeColor(plan.planType)}`}>
                    {plan.planType.charAt(0).toUpperCase() + plan.planType.slice(1)}
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                  <div className="flex items-center justify-center space-x-1">
                    <span className="text-3xl font-bold text-gray-900">${plan.price}</span>
                    <span className="text-gray-500">/ {getDurationText(plan.duration)}</span>
                  </div>
                </div>

                <div className="space-y-3 mb-6">
                  {plan.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm text-gray-600">{feature}</span>
                    </div>
                  ))}
                </div>

                <div className="flex space-x-2">
                  <Button
                    variant="secondary"
                    size="sm"
                    icon={Edit}
                    onClick={() => handleEdit(plan)}
                    className="flex-1"
                  >
                    Edit
                  </Button>
                  <Button
                    variant="danger"
                    size="sm"
                    icon={Trash2}
                    onClick={() => handleDelete(plan)}
                  >
                  </Button>
                </div>
              </Card>
            ))}
          </div>

          {filteredPlans.length === 0 && (
            <Card>
              <div className="text-center py-12">
                <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No plans found</h3>
                <p className="text-gray-500 mb-4">
                  {searchTerm || filterType !== 'all' 
                    ? 'Try adjusting your search or filter criteria' 
                    : 'Get started by creating your first subscription plan'}
                </p>
                <Button
                  icon={Plus}
                  onClick={() => setIsAddModalOpen(true)}
                >
                  Add Plan
                </Button>
              </div>
            </Card>
          )}
        </>
      )}

      {activeTab === 'members' && <MemberSubscriptions />}

      {/* Add Plan Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Add New Subscription Plan"
        size="lg"
      >
        <SubscriptionPlanForm
          onSuccess={() => {
            setIsAddModalOpen(false);
          }}
          onCancel={() => setIsAddModalOpen(false)}
        />
      </Modal>

      {/* Edit Plan Modal */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => {
          setIsEditModalOpen(false);
          setSelectedPlan(null);
        }}
        title="Edit Subscription Plan"
        size="lg"
      >
        <SubscriptionPlanForm
          plan={selectedPlan}
          onSuccess={() => {
            setIsEditModalOpen(false);
            setSelectedPlan(null);
          }}
          onCancel={() => {
            setIsEditModalOpen(false);
            setSelectedPlan(null);
          }}
        />
      </Modal>
    </div>
  );
};

export default Subscriptions;