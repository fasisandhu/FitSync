import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import Button from '../../components/UI/Button';
import { useApp } from '../../contexts/AppContext';
import { format, addMonths } from 'date-fns';

const assignSchema = z.object({
  memberId: z.string().min(1, 'Please select a member'),
  planId: z.string().min(1, 'Please select a plan'),
  startDate: z.string().min(1, 'Start date is required'),
  autoRenew: z.boolean(),
});

type AssignFormData = z.infer<typeof assignSchema>;

interface AssignSubscriptionFormProps {
  onSuccess: () => void;
  onCancel: () => void;
}

const AssignSubscriptionForm: React.FC<AssignSubscriptionFormProps> = ({ onSuccess, onCancel }) => {
  const { members, subscriptionPlans, addMemberSubscription } = useApp();

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<AssignFormData>({
    resolver: zodResolver(assignSchema),
    defaultValues: {
      startDate: format(new Date(), 'yyyy-MM-dd'),
      autoRenew: false,
    }
  });

  const selectedPlanId = watch('planId');
  const selectedPlan = subscriptionPlans.find(plan => plan.id === selectedPlanId);
  const startDate = watch('startDate');

  const calculateEndDate = () => {
    if (!selectedPlan || !startDate) return '';
    const start = new Date(startDate);
    const end = addMonths(start, selectedPlan.duration);
    return format(end, 'yyyy-MM-dd');
  };

  const onSubmit = async (data: AssignFormData) => {
    try {
      const endDate = calculateEndDate();
      
      const subscriptionData = {
        memberId: data.memberId,
        planId: data.planId,
        startDate: data.startDate,
        endDate,
        status: 'active' as const,
        autoRenew: data.autoRenew,
      };

      addMemberSubscription(subscriptionData);
      onSuccess();
    } catch (error) {
      console.error('Error assigning subscription:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="text-lg font-medium text-gray-900">Assignment Details</h3>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Select Member *
            </label>
            <select
              {...register('memberId')}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Choose a member</option>
              {members.map((member) => (
                <option key={member.id} value={member.id}>
                  {member.name} - {member.email}
                </option>
              ))}
            </select>
            {errors.memberId && (
              <p className="text-red-600 text-sm mt-1">{errors.memberId.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Select Plan *
            </label>
            <select
              {...register('planId')}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Choose a plan</option>
              {subscriptionPlans.filter(plan => plan.isActive).map((plan) => (
                <option key={plan.id} value={plan.id}>
                  {plan.name} - ${plan.price} ({plan.duration} months)
                </option>
              ))}
            </select>
            {errors.planId && (
              <p className="text-red-600 text-sm mt-1">{errors.planId.message}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Start Date *
            </label>
            <input
              {...register('startDate')}
              type="date"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            {errors.startDate && (
              <p className="text-red-600 text-sm mt-1">{errors.startDate.message}</p>
            )}
          </div>

          <div className="flex items-center">
            <input
              {...register('autoRenew')}
              type="checkbox"
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
            />
            <label className="ml-2 block text-sm text-gray-700">
              Enable Auto-Renewal
            </label>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-medium text-gray-900">Subscription Preview</h3>
          
          {selectedPlan ? (
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg p-6 border border-blue-200">
              <div className="text-center mb-4">
                <h4 className="text-xl font-bold text-gray-900">{selectedPlan.name}</h4>
                <div className="flex items-center justify-center space-x-1 mt-2">
                  <span className="text-2xl font-bold text-blue-600">${selectedPlan.price}</span>
                  <span className="text-gray-500">/ {selectedPlan.duration} months</span>
                </div>
              </div>
              
              <div className="space-y-3 mb-4">
                {selectedPlan.features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-sm text-gray-600">{feature}</span>
                  </div>
                ))}
              </div>

              {startDate && (
                <div className="border-t pt-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Start Date:</span>
                    <span className="font-medium">{format(new Date(startDate), 'MMM dd, yyyy')}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">End Date:</span>
                    <span className="font-medium">{format(new Date(calculateEndDate()), 'MMM dd, yyyy')}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Duration:</span>
                    <span className="font-medium">{selectedPlan.duration} months</span>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-gray-50 rounded-lg p-6 text-center">
              <p className="text-gray-500">Select a plan to see preview</p>
            </div>
          )}
        </div>
      </div>

      {/* Form Actions */}
      <div className="flex justify-end space-x-3 pt-6 border-t">
        <Button
          type="button"
          variant="secondary"
          onClick={onCancel}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          disabled={isSubmitting}
        >
          {isSubmitting ? 'Assigning...' : 'Assign Subscription'}
        </Button>
      </div>
    </form>
  );
};

export default AssignSubscriptionForm;