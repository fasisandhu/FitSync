import React from 'react';
import { Users, UserCheck, Calendar, DollarSign, TrendingUp, Clock } from 'lucide-react';
import Card from '../../components/UI/Card';
import { useApp } from '../../contexts/AppContext';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

const Dashboard = () => {
  const { dashboardStats, members, attendanceRecords } = useApp();

  // Mock data for charts
  const attendanceData = [
    { day: 'Mon', attendance: 45 },
    { day: 'Tue', attendance: 52 },
    { day: 'Wed', attendance: 38 },
    { day: 'Thu', attendance: 61 },
    { day: 'Fri', attendance: 55 },
    { day: 'Sat', attendance: 67 },
    { day: 'Sun', attendance: 43 },
  ];

  const revenueData = [
    { month: 'Jan', revenue: 4500 },
    { month: 'Feb', revenue: 5200 },
    { month: 'Mar', revenue: 4800 },
    { month: 'Apr', revenue: 6100 },
    { month: 'May', revenue: 5900 },
    { month: 'Jun', revenue: 6800 },
  ];

  const membershipData = [
    { name: 'Basic', value: 35, color: '#3B82F6' },
    { name: 'Premium', value: 45, color: '#8B5CF6' },
    { name: 'Elite', value: 20, color: '#10B981' },
  ];

  const statsCards = [
    {
      title: 'Total Members',
      value: dashboardStats.totalMembers,
      icon: Users,
      color: 'bg-gradient-to-r from-blue-500 to-blue-600',
      change: '+12%',
      changeType: 'positive'
    },
    {
      title: 'Active Members',
      value: dashboardStats.activeMembers,
      icon: UserCheck,
      color: 'bg-gradient-to-r from-green-500 to-green-600',
      change: '+8%',
      changeType: 'positive'
    },
    {
      title: 'Today\'s Attendance',
      value: dashboardStats.todayAttendance,
      icon: Calendar,
      color: 'bg-gradient-to-r from-purple-500 to-purple-600',
      change: '+15%',
      changeType: 'positive'
    },
    {
      title: 'Monthly Revenue',
      value: `$${dashboardStats.monthlyRevenue.toLocaleString()}`,
      icon: DollarSign,
      color: 'bg-gradient-to-r from-orange-500 to-orange-600',
      change: '+23%',
      changeType: 'positive'
    }
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statsCards.map((stat, index) => (
          <Card key={index} className="relative overflow-hidden">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                  <span className="text-sm text-green-600">{stat.change}</span>
                  <span className="text-sm text-gray-500 ml-1">vs last month</span>
                </div>
              </div>
              <div className={`p-4 rounded-xl ${stat.color}`}>
                <stat.icon className="h-8 w-8 text-white" />
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Attendance Chart */}
        <Card title="Weekly Attendance" subtitle="Daily attendance trends">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={attendanceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="attendance" fill="url(#attendanceGradient)" radius={[4, 4, 0, 0]} />
              <defs>
                <linearGradient id="attendanceGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#3B82F6" stopOpacity={0.1}/>
                </linearGradient>
              </defs>
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Revenue Chart */}
        <Card title="Revenue Trend" subtitle="Monthly revenue overview">
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip formatter={(value) => [`$${value}`, 'Revenue']} />
              <Line 
                type="monotone" 
                dataKey="revenue" 
                stroke="#8B5CF6" 
                strokeWidth={3}
                dot={{ fill: '#8B5CF6', strokeWidth: 2, r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Membership Distribution */}
        <Card title="Membership Plans" subtitle="Plan distribution">
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={membershipData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={100}
                dataKey="value"
              >
                {membershipData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="mt-4 flex justify-center space-x-4">
            {membershipData.map((item, index) => (
              <div key={index} className="flex items-center">
                <div 
                  className="w-3 h-3 rounded-full mr-2" 
                  style={{ backgroundColor: item.color }}
                ></div>
                <span className="text-sm text-gray-600">{item.name}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Recent Members */}
        <Card title="Recent Members" subtitle="Latest member registrations">
          <div className="space-y-4">
            {members.slice(0, 5).map((member) => (
              <div key={member.id} className="flex items-center space-x-3">
                <img
                  src={member.avatar || 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?w=50'}
                  alt={member.name}
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{member.name}</p>
                  <p className="text-sm text-gray-500">{member.email}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-gray-500">
                    {new Date(member.dateOfJoining).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Quick Actions */}
        <Card title="Quick Actions" subtitle="Frequently used actions">
          <div className="space-y-3">
            <button className="w-full text-left p-3 rounded-lg hover:bg-gray-50 border border-gray-200">
              <div className="flex items-center space-x-3">
                <Users className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="font-medium">Add New Member</p>
                  <p className="text-sm text-gray-500">Register a new gym member</p>
                </div>
              </div>
            </button>
            <button className="w-full text-left p-3 rounded-lg hover:bg-gray-50 border border-gray-200">
              <div className="flex items-center space-x-3">
                <Calendar className="h-5 w-5 text-green-600" />
                <div>
                  <p className="font-medium">Check-in Member</p>
                  <p className="text-sm text-gray-500">Record member attendance</p>
                </div>
              </div>
            </button>
            <button className="w-full text-left p-3 rounded-lg hover:bg-gray-50 border border-gray-200">
              <div className="flex items-center space-x-3">
                <DollarSign className="h-5 w-5 text-orange-600" />
                <div>
                  <p className="font-medium">Process Payment</p>
                  <p className="text-sm text-gray-500">Record member payment</p>
                </div>
              </div>
            </button>
          </div>
        </Card>
      </div>

      {/* Peak Hours */}
      <Card title="Today's Peak Hours" subtitle="Gym usage patterns">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {[
            { time: '6-8 AM', usage: 85, label: 'Morning Rush' },
            { time: '8-10 AM', usage: 45, label: 'Light' },
            { time: '10-12 PM', usage: 30, label: 'Quiet' },
            { time: '12-2 PM', usage: 60, label: 'Lunch Break' },
            { time: '5-7 PM', usage: 95, label: 'Evening Peak' },
            { time: '7-9 PM', usage: 70, label: 'Moderate' },
          ].map((slot, index) => (
            <div key={index} className="text-center">
              <div className="relative">
                <div className="w-16 h-16 mx-auto bg-gray-200 rounded-full flex items-center justify-center">
                  <div 
                    className="w-12 h-12 rounded-full flex items-center justify-center text-white text-sm font-medium"
                    style={{
                      background: `conic-gradient(from 0deg, #3B82F6 0deg, #3B82F6 ${slot.usage * 3.6}deg, #E5E7EB ${slot.usage * 3.6}deg, #E5E7EB 360deg)`
                    }}
                  >
                    {slot.usage}%
                  </div>
                </div>
                <Clock className="absolute -top-1 -right-1 h-4 w-4 text-blue-600" />
              </div>
              <p className="text-sm font-medium mt-2">{slot.time}</p>
              <p className="text-xs text-gray-500">{slot.label}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default Dashboard;