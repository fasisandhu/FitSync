import React from 'react';
import { Download, Printer } from 'lucide-react';
import Button from '../../components/UI/Button';
import { format, parseISO } from 'date-fns';

interface InvoiceGeneratorProps {
  payment: any;
  onClose: () => void;
}

const InvoiceGenerator: React.FC<InvoiceGeneratorProps> = ({ payment, onClose }) => {
  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    // In a real application, you would generate a PDF here
    const element = document.getElementById('invoice-content');
    if (element) {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Invoice ${payment.invoiceNumber}</title>
              <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                .invoice-header { text-align: center; margin-bottom: 30px; }
                .invoice-details { margin-bottom: 20px; }
                .invoice-table { width: 100%; border-collapse: collapse; }
                .invoice-table th, .invoice-table td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                .invoice-table th { background-color: #f2f2f2; }
                .total-section { margin-top: 20px; text-align: right; }
              </style>
            </head>
            <body>
              ${element.innerHTML}
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.print();
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Action Buttons */}
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-gray-900">Invoice #{payment.invoiceNumber}</h2>
        <div className="flex space-x-2">
          <Button
            variant="secondary"
            icon={Printer}
            onClick={handlePrint}
          >
            Print
          </Button>
          <Button
            variant="secondary"
            icon={Download}
            onClick={handleDownload}
          >
            Download
          </Button>
          <Button
            variant="secondary"
            onClick={onClose}
          >
            Close
          </Button>
        </div>
      </div>

      {/* Invoice Content */}
      <div id="invoice-content" className="bg-white p-8 border border-gray-200 rounded-lg">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">GymPro</h1>
          <p className="text-gray-600">Professional Gym Management</p>
          <p className="text-sm text-gray-500">123 Fitness Street, Gym City, GC 12345</p>
          <p className="text-sm text-gray-500">Phone: (555) 123-4567 | Email: info@gympro.com</p>
        </div>

        {/* Invoice Details */}
        <div className="grid grid-cols-2 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-3">Bill To:</h3>
            <div className="space-y-1">
              <p className="font-medium text-gray-900">{payment.member.name}</p>
              <p className="text-gray-600">{payment.member.email}</p>
              <p className="text-gray-600">{payment.member.phone}</p>
              <p className="text-gray-600">{payment.member.address}</p>
            </div>
          </div>
          <div className="text-right">
            <div className="space-y-2">
              <div>
                <span className="text-sm text-gray-500">Invoice Number:</span>
                <p className="font-medium text-gray-900">{payment.invoiceNumber}</p>
              </div>
              <div>
                <span className="text-sm text-gray-500">Invoice Date:</span>
                <p className="font-medium text-gray-900">
                  {format(parseISO(payment.paymentDate), 'MMM dd, yyyy')}
                </p>
              </div>
              <div>
                <span className="text-sm text-gray-500">Due Date:</span>
                <p className="font-medium text-gray-900">
                  {format(parseISO(payment.dueDate), 'MMM dd, yyyy')}
                </p>
              </div>
              <div>
                <span className="text-sm text-gray-500">Status:</span>
                <p className={`font-medium ${
                  payment.status === 'paid' ? 'text-green-600' : 
                  payment.status === 'pending' ? 'text-yellow-600' : 'text-red-600'
                }`}>
                  {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Invoice Items */}
        <div className="mb-8">
          <table className="w-full border-collapse border border-gray-300">
            <thead>
              <tr className="bg-gray-50">
                <th className="border border-gray-300 px-4 py-3 text-left">Description</th>
                <th className="border border-gray-300 px-4 py-3 text-center">Duration</th>
                <th className="border border-gray-300 px-4 py-3 text-right">Amount</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td className="border border-gray-300 px-4 py-3">
                  <div>
                    <p className="font-medium text-gray-900">{payment.plan.name}</p>
                    <div className="text-sm text-gray-600 mt-1">
                      {payment.plan.features.map((feature, index) => (
                        <div key={index}>• {feature}</div>
                      ))}
                    </div>
                  </div>
                </td>
                <td className="border border-gray-300 px-4 py-3 text-center">
                  {payment.plan.duration} month{payment.plan.duration > 1 ? 's' : ''}
                </td>
                <td className="border border-gray-300 px-4 py-3 text-right font-medium">
                  ${payment.amount.toFixed(2)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Totals */}
        <div className="flex justify-end mb-8">
          <div className="w-64">
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Subtotal:</span>
                <span className="font-medium">${payment.amount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Tax (0%):</span>
                <span className="font-medium">$0.00</span>
              </div>
              <div className="border-t pt-2">
                <div className="flex justify-between">
                  <span className="text-lg font-semibold">Total:</span>
                  <span className="text-lg font-bold text-blue-600">${payment.amount.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Payment Information */}
        <div className="border-t pt-6">
          <div className="grid grid-cols-2 gap-8">
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Payment Information</h4>
              <div className="space-y-1 text-sm">
                <p><span className="text-gray-600">Payment Method:</span> {payment.paymentMethod.replace('_', ' ').toUpperCase()}</p>
                {payment.status === 'paid' && (
                  <p><span className="text-gray-600">Payment Date:</span> {format(parseISO(payment.paymentDate), 'MMM dd, yyyy')}</p>
                )}
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 mb-2">Terms & Conditions</h4>
              <div className="text-sm text-gray-600 space-y-1">
                <p>• Payment is due within 30 days of invoice date</p>
                <p>• Late payments may incur additional charges</p>
                <p>• All sales are final</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-8 pt-6 border-t text-sm text-gray-500">
          <p>Thank you for choosing GymPro!</p>
          <p>For questions about this invoice, please contact us at billing@gympro.com</p>
        </div>
      </div>
    </div>
  );
};

export default InvoiceGenerator;