import React, { useState } from 'react';
import { Plus, Search, Filter, Download, DollarSign, CreditCard, AlertCircle, CheckCircle } from 'lucide-react';
import Card from '../../components/UI/Card';
import Button from '../../components/UI/Button';
import Badge from '../../components/UI/Badge';
import Modal from '../../components/UI/Modal';
import { useApp } from '../../contexts/AppContext';
import { format, parseISO, subDays, isAfter } from 'date-fns';
import PaymentForm from './PaymentForm';
import InvoiceGenerator from './InvoiceGenerator';

const Payments = () => {
  const { members, subscriptionPlans, payments, addPayment } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'paid' | 'pending' | 'overdue'>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState<any>(null);

  // Create mock payments for demonstration
  const mockPayments = members.map((member, index) => {
    const plan = subscriptionPlans[index % subscriptionPlans.length];
    const paymentDate = subDays(new Date(), Math.floor(Math.random() * 30));
    const dueDate = subDays(new Date(), Math.floor(Math.random() * 10) - 5);
    const isOverdue = isAfter(new Date(), dueDate);
    const statuses = ['paid', 'pending', 'overdue'];
    const status = isOverdue ? 'overdue' : statuses[Math.floor(Math.random() * 2)];
    
    return {
      id: `payment-${member.id}`,
      memberId: member.id,
      amount: plan.price,
      paymentDate: paymentDate.toISOString(),
      dueDate: dueDate.toISOString(),
      status,
      paymentMethod: ['cash', 'card', 'upi', 'bank_transfer'][Math.floor(Math.random() * 4)],
      subscriptionId: `sub-${member.id}`,
      invoiceNumber: `INV-${String(index + 1).padStart(4, '0')}`,
      member,
      plan
    };
  });

  const filteredPayments = mockPayments.filter(payment => {
    const matchesSearch = payment.member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         payment.member.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         payment.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = filterStatus === 'all' || payment.status === filterStatus;
    
    return matchesSearch && matchesFilter;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return <Badge variant="success">Paid</Badge>;
      case 'pending':
        return <Badge variant="warning">Pending</Badge>;
      case 'overdue':
        return <Badge variant="danger">Overdue</Badge>;
      default:
        return <Badge variant="gray">Unknown</Badge>;
    }
  };

  const getPaymentMethodIcon = (method: string) => {
    switch (method) {
      case 'card':
        return <CreditCard className="h-4 w-4" />;
      case 'cash':
        return <DollarSign className="h-4 w-4" />;
      default:
        return <DollarSign className="h-4 w-4" />;
    }
  };

  const handleGenerateInvoice = (payment: any) => {
    setSelectedPayment(payment);
    setIsInvoiceModalOpen(true);
  };

  const exportPayments = () => {
    const csvContent = [
      ['Invoice Number', 'Member Name', 'Amount', 'Due Date', 'Payment Date', 'Status', 'Payment Method'],
      ...filteredPayments.map(payment => [
        payment.invoiceNumber,
        payment.member.name,
        payment.amount,
        format(parseISO(payment.dueDate), 'yyyy-MM-dd'),
        payment.status === 'paid' ? format(parseISO(payment.paymentDate), 'yyyy-MM-dd') : 'N/A',
        payment.status,
        payment.paymentMethod
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `payments-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const totalRevenue = mockPayments.filter(p => p.status === 'paid').reduce((sum, p) => sum + p.amount, 0);
  const pendingAmount = mockPayments.filter(p => p.status === 'pending').reduce((sum, p) => sum + p.amount, 0);
  const overdueAmount = mockPayments.filter(p => p.status === 'overdue').reduce((sum, p) => sum + p.amount, 0);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Payments</h1>
          <p className="text-gray-600">Track payments and manage invoices</p>
        </div>
        <div className="flex space-x-2">
          <Button
            variant="secondary"
            icon={Download}
            onClick={exportPayments}
          >
            Export
          </Button>
          <Button
            icon={Plus}
            onClick={() => setIsAddModalOpen(true)}
          >
            Record Payment
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900">${totalRevenue.toLocaleString()}</p>
            </div>
            <div className="p-3 bg-green-100 rounded-lg">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Pending Payments</p>
              <p className="text-2xl font-bold text-gray-900">${pendingAmount.toLocaleString()}</p>
            </div>
            <div className="p-3 bg-yellow-100 rounded-lg">
              <DollarSign className="h-6 w-6 text-yellow-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Overdue Amount</p>
              <p className="text-2xl font-bold text-gray-900">${overdueAmount.toLocaleString()}</p>
            </div>
            <div className="p-3 bg-red-100 rounded-lg">
              <AlertCircle className="h-6 w-6 text-red-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">This Month</p>
              <p className="text-2xl font-bold text-gray-900">
                ${mockPayments.filter(p => p.status === 'paid').length}
              </p>
            </div>
            <div className="p-3 bg-blue-100 rounded-lg">
              <CreditCard className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="text"
              placeholder="Search payments..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Payments</option>
              <option value="paid">Paid</option>
              <option value="pending">Pending</option>
              <option value="overdue">Overdue</option>
            </select>
          </div>
        </div>
      </Card>

      {/* Payments Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-900">Invoice</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Member</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Amount</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Due Date</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Status</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Method</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredPayments.map((payment) => (
                <tr key={payment.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-4 px-4">
                    <div>
                      <p className="font-medium text-gray-900">{payment.invoiceNumber}</p>
                      <p className="text-sm text-gray-500">{payment.plan.name}</p>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center space-x-3">
                      <img
                        src={payment.member.avatar || 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?w=50'}
                        alt={payment.member.name}
                        className="w-8 h-8 rounded-full object-cover"
                      />
                      <div>
                        <p className="font-medium text-gray-900">{payment.member.name}</p>
                        <p className="text-sm text-gray-500">{payment.member.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <p className="font-medium text-gray-900">${payment.amount}</p>
                  </td>
                  <td className="py-4 px-4">
                    <p className="text-gray-900">{format(parseISO(payment.dueDate), 'MMM dd, yyyy')}</p>
                    {payment.status === 'overdue' && (
                      <p className="text-sm text-red-600">
                        {Math.abs(Math.floor((new Date().getTime() - parseISO(payment.dueDate).getTime()) / (1000 * 60 * 60 * 24)))} days overdue
                      </p>
                    )}
                  </td>
                  <td className="py-4 px-4">
                    {getStatusBadge(payment.status)}
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center space-x-2">
                      {getPaymentMethodIcon(payment.paymentMethod)}
                      <span className="text-sm text-gray-600 capitalize">
                        {payment.paymentMethod.replace('_', ' ')}
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => handleGenerateInvoice(payment)}
                      >
                        Invoice
                      </Button>
                      {payment.status !== 'paid' && (
                        <Button size="sm" variant="success">
                          Mark Paid
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Record Payment Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Record Payment"
        size="lg"
      >
        <PaymentForm
          onSuccess={() => {
            setIsAddModalOpen(false);
          }}
          onCancel={() => setIsAddModalOpen(false)}
        />
      </Modal>

      {/* Invoice Modal */}
      <Modal
        isOpen={isInvoiceModalOpen}
        onClose={() => {
          setIsInvoiceModalOpen(false);
          setSelectedPayment(null);
        }}
        title="Invoice Details"
        size="xl"
      >
        {selectedPayment && (
          <InvoiceGenerator
            payment={selectedPayment}
            onClose={() => {
              setIsInvoiceModalOpen(false);
              setSelectedPayment(null);
            }}
          />
        )}
      </Modal>
    </div>
  );
};

export default Payments;