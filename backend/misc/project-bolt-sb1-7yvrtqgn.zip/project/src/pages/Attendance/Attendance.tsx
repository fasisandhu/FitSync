import React, { useState } from 'react';
import { Calendar, Clock, Users, Search, Filter, CheckCircle, XCircle, Download } from 'lucide-react';
import Card from '../../components/UI/Card';
import Button from '../../components/UI/Button';
import Badge from '../../components/UI/Badge';
import { useApp } from '../../contexts/AppContext';
import { format, startOfWeek, endOfWeek, eachDayOfInterval, isSameDay, parseISO } from 'date-fns';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

const Attendance = () => {
  const { members, attendanceRecords, checkIn, checkOut } = useApp();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'today' | 'week' | 'analytics'>('today');

  const todayRecords = attendanceRecords.filter(record => 
    isSameDay(parseISO(record.date), selectedDate)
  );

  const weekStart = startOfWeek(selectedDate);
  const weekEnd = endOfWeek(selectedDate);
  const weekDays = eachDayOfInterval({ start: weekStart, end: weekEnd });

  const weeklyData = weekDays.map(day => {
    const dayRecords = attendanceRecords.filter(record => 
      isSameDay(parseISO(record.date), day)
    );
    return {
      day: format(day, 'EEE'),
      date: format(day, 'MMM dd'),
      attendance: dayRecords.length,
      checkedIn: dayRecords.filter(r => r.checkIn && !r.checkOut).length,
      checkedOut: dayRecords.filter(r => r.checkOut).length
    };
  });

  const hourlyData = Array.from({ length: 24 }, (_, hour) => {
    const hourRecords = todayRecords.filter(record => {
      const checkInHour = new Date(record.checkIn).getHours();
      return checkInHour === hour;
    });
    return {
      hour: `${hour}:00`,
      checkins: hourRecords.length
    };
  });

  const filteredMembers = members.filter(member =>
    member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    member.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getMemberStatus = (memberId: string) => {
    const todayRecord = todayRecords.find(record => record.memberId === memberId);
    if (!todayRecord) return 'absent';
    if (todayRecord.checkIn && !todayRecord.checkOut) return 'present';
    if (todayRecord.checkOut) return 'completed';
    return 'absent';
  };

  const handleCheckIn = (memberId: string) => {
    checkIn(memberId);
  };

  const handleCheckOut = (memberId: string) => {
    checkOut(memberId);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'present':
        return <Badge variant="warning">Checked In</Badge>;
      case 'completed':
        return <Badge variant="success">Completed</Badge>;
      case 'absent':
      default:
        return <Badge variant="gray">Not Checked In</Badge>;
    }
  };

  const exportAttendance = () => {
    const csvContent = [
      ['Date', 'Member Name', 'Check In', 'Check Out', 'Duration (minutes)'],
      ...todayRecords.map(record => {
        const member = members.find(m => m.id === record.memberId);
        return [
          record.date,
          member?.name || 'Unknown',
          record.checkIn,
          record.checkOut || 'Not checked out',
          record.duration?.toString() || 'N/A'
        ];
      })
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `attendance-${format(selectedDate, 'yyyy-MM-dd')}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Attendance</h1>
          <p className="text-gray-600">Track member check-ins and attendance patterns</p>
        </div>
        <div className="flex space-x-2">
          <Button
            variant="secondary"
            icon={Download}
            onClick={exportAttendance}
          >
            Export
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Today's Attendance</p>
              <p className="text-2xl font-bold text-gray-900">{todayRecords.length}</p>
            </div>
            <div className="p-3 bg-blue-100 rounded-lg">
              <Users className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Currently Present</p>
              <p className="text-2xl font-bold text-gray-900">
                {todayRecords.filter(r => r.checkIn && !r.checkOut).length}
              </p>
            </div>
            <div className="p-3 bg-green-100 rounded-lg">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Completed Sessions</p>
              <p className="text-2xl font-bold text-gray-900">
                {todayRecords.filter(r => r.checkOut).length}
              </p>
            </div>
            <div className="p-3 bg-purple-100 rounded-lg">
              <XCircle className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Avg. Session Time</p>
              <p className="text-2xl font-bold text-gray-900">
                {Math.round(
                  todayRecords
                    .filter(r => r.duration)
                    .reduce((sum, r) => sum + (r.duration || 0), 0) /
                  todayRecords.filter(r => r.duration).length || 0
                )}m
              </p>
            </div>
            <div className="p-3 bg-orange-100 rounded-lg">
              <Clock className="h-6 w-6 text-orange-600" />
            </div>
          </div>
        </Card>
      </div>

      {/* View Mode Tabs */}
      <Card>
        <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg">
          {[
            { key: 'today', label: 'Today', icon: Calendar },
            { key: 'week', label: 'Weekly View', icon: Calendar },
            { key: 'analytics', label: 'Analytics', icon: BarChart }
          ].map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setViewMode(key as any)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-md transition-colors ${
                viewMode === key
                  ? 'bg-white text-blue-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{label}</span>
            </button>
          ))}
        </div>
      </Card>

      {/* Date Selector */}
      <Card>
        <div className="flex items-center space-x-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Select Date
            </label>
            <input
              type="date"
              value={format(selectedDate, 'yyyy-MM-dd')}
              onChange={(e) => setSelectedDate(new Date(e.target.value))}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Search Members
            </label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Search members..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>
      </Card>

      {/* Content based on view mode */}
      {viewMode === 'today' && (
        <Card title="Today's Attendance" subtitle={format(selectedDate, 'EEEE, MMMM dd, yyyy')}>
          <div className="space-y-4">
            {filteredMembers.map((member) => {
              const status = getMemberStatus(member.id);
              const record = todayRecords.find(r => r.memberId === member.id);
              
              return (
                <div key={member.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-4">
                    <img
                      src={member.avatar || 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?w=50'}
                      alt={member.name}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div>
                      <p className="font-medium text-gray-900">{member.name}</p>
                      <p className="text-sm text-gray-500">{member.email}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    {record && (
                      <div className="text-sm text-gray-600">
                        <p>In: {format(new Date(record.checkIn), 'HH:mm')}</p>
                        {record.checkOut && (
                          <p>Out: {format(new Date(record.checkOut), 'HH:mm')}</p>
                        )}
                      </div>
                    )}
                    
                    {getStatusBadge(status)}
                    
                    <div className="flex space-x-2">
                      {status === 'absent' && (
                        <Button
                          size="sm"
                          variant="success"
                          onClick={() => handleCheckIn(member.id)}
                        >
                          Check In
                        </Button>
                      )}
                      {status === 'present' && (
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => handleCheckOut(member.id)}
                        >
                          Check Out
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {viewMode === 'week' && (
        <Card title="Weekly Attendance" subtitle={`${format(weekStart, 'MMM dd')} - ${format(weekEnd, 'MMM dd, yyyy')}`}>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={weeklyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip 
                formatter={(value, name) => [value, name === 'attendance' ? 'Total Attendance' : name]}
                labelFormatter={(label) => {
                  const day = weeklyData.find(d => d.day === label);
                  return day ? `${day.day}, ${day.date}` : label;
                }}
              />
              <Bar dataKey="attendance" fill="#3B82F6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      )}

      {viewMode === 'analytics' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card title="Hourly Check-ins" subtitle="Today's check-in pattern">
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={hourlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="hour" />
                <YAxis />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="checkins" 
                  stroke="#8B5CF6" 
                  strokeWidth={2}
                  dot={{ fill: '#8B5CF6', strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          <Card title="Weekly Trends" subtitle="Attendance over the week">
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="checkedIn" stackId="a" fill="#10B981" name="Currently Present" />
                <Bar dataKey="checkedOut" stackId="a" fill="#3B82F6" name="Completed Sessions" />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </div>
      )}
    </div>
  );
};

export default Attendance;