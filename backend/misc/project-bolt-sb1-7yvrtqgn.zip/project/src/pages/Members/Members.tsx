import React, { useState } from 'react';
import { Plus, Search, Filter, Eye, Edit, Trash2, UserPlus } from 'lucide-react';
import Card from '../../components/UI/Card';
import Button from '../../components/UI/Button';
import Badge from '../../components/UI/Badge';
import Modal from '../../components/UI/Modal';
import { useApp } from '../../contexts/AppContext';
import { Member } from '../../types';
import MemberForm from './MemberForm';
import MemberDetails from './MemberDetails';

const Members = () => {
  const { members, deleteMember } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);

  const filteredMembers = members.filter(member => {
    const matchesSearch = member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         member.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || 
                         (filterStatus === 'active' && member.isActive) ||
                         (filterStatus === 'inactive' && !member.isActive);
    return matchesSearch && matchesFilter;
  });

  const handleEdit = (member: Member) => {
    setSelectedMember(member);
    setIsEditModalOpen(true);
  };

  const handleView = (member: Member) => {
    setSelectedMember(member);
    setIsDetailsModalOpen(true);
  };

  const handleDelete = (member: Member) => {
    if (window.confirm(`Are you sure you want to delete ${member.name}?`)) {
      deleteMember(member.id);
    }
  };

  const getStatusBadge = (member: Member) => {
    if (!member.isActive) {
      return <Badge variant="danger">Inactive</Badge>;
    }
    
    switch (member.subscriptionStatus) {
      case 'active':
        return <Badge variant="success">Active</Badge>;
      case 'expired':
        return <Badge variant="danger">Expired</Badge>;
      case 'pending':
        return <Badge variant="warning">Pending</Badge>;
      default:
        return <Badge variant="gray">Unknown</Badge>;
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Members</h1>
          <p className="text-gray-600">Manage gym members and their information</p>
        </div>
        <Button
          icon={Plus}
          onClick={() => setIsAddModalOpen(true)}
        >
          Add Member
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="text"
              placeholder="Search members..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Members</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>
      </Card>

      {/* Members Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMembers.map((member) => (
          <Card key={member.id} className="hover:shadow-lg transition-shadow duration-200">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <img
                  src={member.avatar || 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?w=100'}
                  alt={member.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-gray-200"
                />
                <div>
                  <h3 className="font-semibold text-gray-900">{member.name}</h3>
                  <p className="text-sm text-gray-500">{member.email}</p>
                </div>
              </div>
              {getStatusBadge(member)}
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Phone:</span>
                <span className="text-gray-900">{member.phone}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Joined:</span>
                <span className="text-gray-900">
                  {new Date(member.dateOfJoining).toLocaleDateString()}
                </span>
              </div>
              {member.assignedTrainer && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Trainer:</span>
                  <span className="text-gray-900">Assigned</span>
                </div>
              )}
            </div>

            <div className="flex space-x-2">
              <Button
                variant="secondary"
                size="sm"
                icon={Eye}
                onClick={() => handleView(member)}
                className="flex-1"
              >
                View
              </Button>
              <Button
                variant="secondary"
                size="sm"
                icon={Edit}
                onClick={() => handleEdit(member)}
                className="flex-1"
              >
                Edit
              </Button>
              <Button
                variant="danger"
                size="sm"
                icon={Trash2}
                onClick={() => handleDelete(member)}
              >
              </Button>
            </div>
          </Card>
        ))}
      </div>

      {filteredMembers.length === 0 && (
        <Card>
          <div className="text-center py-12">
            <UserPlus className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No members found</h3>
            <p className="text-gray-500 mb-4">
              {searchTerm || filterStatus !== 'all' 
                ? 'Try adjusting your search or filter criteria' 
                : 'Get started by adding your first member'}
            </p>
            <Button
              icon={Plus}
              onClick={() => setIsAddModalOpen(true)}
            >
              Add Member
            </Button>
          </div>
        </Card>
      )}

      {/* Add Member Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Add New Member"
        size="lg"
      >
        <MemberForm
          onSuccess={() => {
            setIsAddModalOpen(false);
          }}
          onCancel={() => setIsAddModalOpen(false)}
        />
      </Modal>

      {/* Edit Member Modal */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => {
          setIsEditModalOpen(false);
          setSelectedMember(null);
        }}
        title="Edit Member"
        size="lg"
      >
        <MemberForm
          member={selectedMember}
          onSuccess={() => {
            setIsEditModalOpen(false);
            setSelectedMember(null);
          }}
          onCancel={() => {
            setIsEditModalOpen(false);
            setSelectedMember(null);
          }}
        />
      </Modal>

      {/* Member Details Modal */}
      <Modal
        isOpen={isDetailsModalOpen}
        onClose={() => {
          setIsDetailsModalOpen(false);
          setSelectedMember(null);
        }}
        title="Member Details"
        size="lg"
      >
        {selectedMember && (
          <MemberDetails
            member={selectedMember}
            onEdit={() => {
              setIsDetailsModalOpen(false);
              setIsEditModalOpen(true);
            }}
            onClose={() => {
              setIsDetailsModalOpen(false);
              setSelectedMember(null);
            }}
          />
        )}
      </Modal>
    </div>
  );
};

export default Members;