import React from 'react';
import { Edit, Mail, Phone, MapPin, Calendar, User, AlertCircle } from 'lucide-react';
import Button from '../../components/UI/Button';
import Badge from '../../components/UI/Badge';
import { Member } from '../../types';
import { useApp } from '../../contexts/AppContext';

interface MemberDetailsProps {
  member: Member;
  onEdit: () => void;
  onClose: () => void;
}

const MemberDetails: React.FC<MemberDetailsProps> = ({ member, onEdit, onClose }) => {
  const { trainers } = useApp();
  
  const assignedTrainer = member.assignedTrainer 
    ? trainers.find(t => t.id === member.assignedTrainer)
    : null;

  const getStatusBadge = () => {
    if (!member.isActive) {
      return <Badge variant="danger">Inactive</Badge>;
    }
    
    switch (member.subscriptionStatus) {
      case 'active':
        return <Badge variant="success">Active</Badge>;
      case 'expired':
        return <Badge variant="danger">Expired</Badge>;
      case 'pending':
        return <Badge variant="warning">Pending</Badge>;
      default:
        return <Badge variant="gray">Unknown</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="flex items-center space-x-4">
          <img
            src={member.avatar || 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?w=100'}
            alt={member.name}
            className="w-20 h-20 rounded-full object-cover border-4 border-gray-200"
          />
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{member.name}</h2>
            <p className="text-gray-600">{member.email}</p>
            <div className="mt-2">{getStatusBadge()}</div>
          </div>
        </div>
        <Button icon={Edit} onClick={onEdit}>
          Edit Member
        </Button>
      </div>

      {/* Personal Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Personal Information</h3>
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <Mail className="h-4 w-4 text-gray-500" />
              <div>
                <p className="text-sm text-gray-500">Email</p>
                <p className="font-medium">{member.email}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Phone className="h-4 w-4 text-gray-500" />
              <div>
                <p className="text-sm text-gray-500">Phone</p>
                <p className="font-medium">{member.phone}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <User className="h-4 w-4 text-gray-500" />
              <div>
                <p className="text-sm text-gray-500">Gender</p>
                <p className="font-medium capitalize">{member.gender}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Calendar className="h-4 w-4 text-gray-500" />
              <div>
                <p className="text-sm text-gray-500">Date of Birth</p>
                <p className="font-medium">{new Date(member.dateOfBirth).toLocaleDateString()}</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <MapPin className="h-4 w-4 text-gray-500 mt-1" />
              <div>
                <p className="text-sm text-gray-500">Address</p>
                <p className="font-medium">{member.address}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Gym Information</h3>
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <Calendar className="h-4 w-4 text-gray-500" />
              <div>
                <p className="text-sm text-gray-500">Date of Joining</p>
                <p className="font-medium">{new Date(member.dateOfJoining).toLocaleDateString()}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <User className="h-4 w-4 text-gray-500" />
              <div>
                <p className="text-sm text-gray-500">Assigned Trainer</p>
                <p className="font-medium">
                  {assignedTrainer ? assignedTrainer.name : 'Not Assigned'}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className={`h-3 w-3 rounded-full ${member.isActive ? 'bg-green-500' : 'bg-red-500'}`} />
              <div>
                <p className="text-sm text-gray-500">Membership Status</p>
                <p className="font-medium">{member.isActive ? 'Active' : 'Inactive'}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Emergency Contact */}
      <div className="bg-orange-50 rounded-lg p-6 border border-orange-200">
        <div className="flex items-center space-x-2 mb-4">
          <AlertCircle className="h-5 w-5 text-orange-600" />
          <h3 className="text-lg font-semibold text-orange-900">Emergency Contact</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <p className="text-sm text-orange-700">Contact Name</p>
            <p className="font-medium text-orange-900">{member.emergencyContact.name}</p>
          </div>
          <div>
            <p className="text-sm text-orange-700">Phone Number</p>
            <p className="font-medium text-orange-900">{member.emergencyContact.phone}</p>
          </div>
          <div>
            <p className="text-sm text-orange-700">Relationship</p>
            <p className="font-medium text-orange-900">{member.emergencyContact.relationship}</p>
          </div>
        </div>
      </div>

      {/* Trainer Details */}
      {assignedTrainer && (
        <div className="bg-blue-50 rounded-lg p-6 border border-blue-200">
          <h3 className="text-lg font-semibold text-blue-900 mb-4">Assigned Trainer</h3>
          <div className="flex items-center space-x-4">
            <img
              src={assignedTrainer.avatar || 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?w=60'}
              alt={assignedTrainer.name}
              className="w-12 h-12 rounded-full object-cover"
            />
            <div>
              <p className="font-medium text-blue-900">{assignedTrainer.name}</p>
              <p className="text-sm text-blue-700">{assignedTrainer.specialization.join(', ')}</p>
              <p className="text-sm text-blue-600">{assignedTrainer.experience} years experience</p>
            </div>
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex justify-end space-x-3 pt-6 border-t">
        <Button variant="secondary" onClick={onClose}>
          Close
        </Button>
        <Button icon={Edit} onClick={onEdit}>
          Edit Member
        </Button>
      </div>
    </div>
  );
};

export default MemberDetails;