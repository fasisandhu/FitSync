import React, { useState } from 'react';
import { Plus, Search, Filter, Eye, Edit, Trash2, UserCheck, Award, Users } from 'lucide-react';
import Card from '../../components/UI/Card';
import Button from '../../components/UI/Button';
import Badge from '../../components/UI/Badge';
import Modal from '../../components/UI/Modal';
import { useApp } from '../../contexts/AppContext';
import { Trainer } from '../../types';
import TrainerForm from './TrainerForm';
import TrainerDetails from './TrainerDetails';

const Trainers = () => {
  const { trainers, deleteTrainer } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'inactive'>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [selectedTrainer, setSelectedTrainer] = useState<Trainer | null>(null);

  const filteredTrainers = trainers.filter(trainer => {
    const matchesSearch = trainer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         trainer.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         trainer.specialization.some(spec => spec.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesFilter = filterStatus === 'all' || 
                         (filterStatus === 'active' && trainer.isActive) ||
                         (filterStatus === 'inactive' && !trainer.isActive);
    return matchesSearch && matchesFilter;
  });

  const handleEdit = (trainer: Trainer) => {
    setSelectedTrainer(trainer);
    setIsEditModalOpen(true);
  };

  const handleView = (trainer: Trainer) => {
    setSelectedTrainer(trainer);
    setIsDetailsModalOpen(true);
  };

  const handleDelete = (trainer: Trainer) => {
    if (window.confirm(`Are you sure you want to delete ${trainer.name}?`)) {
      deleteTrainer(trainer.id);
    }
  };

  const getWorkloadColor = (score: number) => {
    if (score >= 80) return 'text-red-600 bg-red-100';
    if (score >= 60) return 'text-yellow-600 bg-yellow-100';
    return 'text-green-600 bg-green-100';
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Trainers</h1>
          <p className="text-gray-600">Manage gym trainers and their assignments</p>
        </div>
        <Button
          icon={Plus}
          onClick={() => setIsAddModalOpen(true)}
        >
          Add Trainer
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="text"
              placeholder="Search trainers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Trainers</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>
      </Card>

      {/* Trainers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTrainers.map((trainer) => (
          <Card key={trainer.id} className="hover:shadow-lg transition-shadow duration-200">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                <img
                  src={trainer.avatar || 'https://images.pexels.com/photos/1431282/pexels-photo-1431282.jpeg?w=100'}
                  alt={trainer.name}
                  className="w-12 h-12 rounded-full object-cover border-2 border-gray-200"
                />
                <div>
                  <h3 className="font-semibold text-gray-900">{trainer.name}</h3>
                  <p className="text-sm text-gray-500">{trainer.email}</p>
                </div>
              </div>
              <Badge variant={trainer.isActive ? 'success' : 'danger'}>
                {trainer.isActive ? 'Active' : 'Inactive'}
              </Badge>
            </div>

            <div className="space-y-3 mb-4">
              <div className="flex items-center space-x-2">
                <Award className="h-4 w-4 text-blue-600" />
                <span className="text-sm text-gray-600">
                  {trainer.experience} years experience
                </span>
              </div>
              
              <div className="flex items-center space-x-2">
                <Users className="h-4 w-4 text-green-600" />
                <span className="text-sm text-gray-600">
                  {trainer.assignedMembers.length} assigned members
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Workload:</span>
                <span className={`text-sm px-2 py-1 rounded-full ${getWorkloadColor(trainer.workloadScore)}`}>
                  {trainer.workloadScore}%
                </span>
              </div>

              <div className="flex flex-wrap gap-1">
                {trainer.specialization.slice(0, 2).map((spec, index) => (
                  <Badge key={index} variant="info" size="sm">
                    {spec}
                  </Badge>
                ))}
                {trainer.specialization.length > 2 && (
                  <Badge variant="gray" size="sm">
                    +{trainer.specialization.length - 2} more
                  </Badge>
                )}
              </div>
            </div>

            <div className="flex space-x-2">
              <Button
                variant="secondary"
                size="sm"
                icon={Eye}
                onClick={() => handleView(trainer)}
                className="flex-1"
              >
                View
              </Button>
              <Button
                variant="secondary"
                size="sm"
                icon={Edit}
                onClick={() => handleEdit(trainer)}
                className="flex-1"
              >
                Edit
              </Button>
              <Button
                variant="danger"
                size="sm"
                icon={Trash2}
                onClick={() => handleDelete(trainer)}
              >
              </Button>
            </div>
          </Card>
        ))}
      </div>

      {filteredTrainers.length === 0 && (
        <Card>
          <div className="text-center py-12">
            <UserCheck className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No trainers found</h3>
            <p className="text-gray-500 mb-4">
              {searchTerm || filterStatus !== 'all' 
                ? 'Try adjusting your search or filter criteria' 
                : 'Get started by adding your first trainer'}
            </p>
            <Button
              icon={Plus}
              onClick={() => setIsAddModalOpen(true)}
            >
              Add Trainer
            </Button>
          </div>
        </Card>
      )}

      {/* Add Trainer Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Add New Trainer"
        size="lg"
      >
        <TrainerForm
          onSuccess={() => {
            setIsAddModalOpen(false);
          }}
          onCancel={() => setIsAddModalOpen(false)}
        />
      </Modal>

      {/* Edit Trainer Modal */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => {
          setIsEditModalOpen(false);
          setSelectedTrainer(null);
        }}
        title="Edit Trainer"
        size="lg"
      >
        <TrainerForm
          trainer={selectedTrainer}
          onSuccess={() => {
            setIsEditModalOpen(false);
            setSelectedTrainer(null);
          }}
          onCancel={() => {
            setIsEditModalOpen(false);
            setSelectedTrainer(null);
          }}
        />
      </Modal>

      {/* Trainer Details Modal */}
      <Modal
        isOpen={isDetailsModalOpen}
        onClose={() => {
          setIsDetailsModalOpen(false);
          setSelectedTrainer(null);
        }}
        title="Trainer Details"
        size="lg"
      >
        {selectedTrainer && (
          <TrainerDetails
            trainer={selectedTrainer}
            onEdit={() => {
              setIsDetailsModalOpen(false);
              setIsEditModalOpen(true);
            }}
            onClose={() => {
              setIsDetailsModalOpen(false);
              setSelectedTrainer(null);
            }}
          />
        )}
      </Modal>
    </div>
  );
};

export default Trainers;