import React from 'react';
import { Edit, Mail, Phone, Award, Users, CheckCircle, Star } from 'lucide-react';
import Button from '../../components/UI/Button';
import Badge from '../../components/UI/Badge';
import { Trainer } from '../../types';
import { useApp } from '../../contexts/AppContext';

interface TrainerDetailsProps {
  trainer: Trainer;
  onEdit: () => void;
  onClose: () => void;
}

const TrainerDetails: React.FC<TrainerDetailsProps> = ({ trainer, onEdit, onClose }) => {
  const { members } = useApp();
  
  const assignedMembers = members.filter(member => 
    trainer.assignedMembers.includes(member.id)
  );

  const getWorkloadColor = (score: number) => {
    if (score >= 80) return 'text-red-600 bg-red-100';
    if (score >= 60) return 'text-yellow-600 bg-yellow-100';
    return 'text-green-600 bg-green-100';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="flex items-center space-x-4">
          <img
            src={trainer.avatar || 'https://images.pexels.com/photos/1431282/pexels-photo-1431282.jpeg?w=100'}
            alt={trainer.name}
            className="w-20 h-20 rounded-full object-cover border-4 border-gray-200"
          />
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{trainer.name}</h2>
            <p className="text-gray-600">{trainer.email}</p>
            <div className="mt-2">
              <Badge variant={trainer.isActive ? 'success' : 'danger'}>
                {trainer.isActive ? 'Active' : 'Inactive'}
              </Badge>
            </div>
          </div>
        </div>
        <Button icon={Edit} onClick={onEdit}>
          Edit Trainer
        </Button>
      </div>

      {/* Personal Information */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact Information</h3>
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <Mail className="h-4 w-4 text-gray-500" />
              <div>
                <p className="text-sm text-gray-500">Email</p>
                <p className="font-medium">{trainer.email}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Phone className="h-4 w-4 text-gray-500" />
              <div>
                <p className="text-sm text-gray-500">Phone</p>
                <p className="font-medium">{trainer.phone}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Award className="h-4 w-4 text-gray-500" />
              <div>
                <p className="text-sm text-gray-500">Experience</p>
                <p className="font-medium">{trainer.experience} years</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Workload & Performance</h3>
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <Users className="h-4 w-4 text-gray-500" />
              <div>
                <p className="text-sm text-gray-500">Assigned Members</p>
                <p className="font-medium">{trainer.assignedMembers.length} members</p>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Workload Score</p>
                <p className="font-medium">Current capacity utilization</p>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getWorkloadColor(trainer.workloadScore)}`}>
                {trainer.workloadScore}%
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${trainer.workloadScore}%` }}
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Specializations */}
      <div className="bg-blue-50 rounded-lg p-6 border border-blue-200">
        <div className="flex items-center space-x-2 mb-4">
          <Star className="h-5 w-5 text-blue-600" />
          <h3 className="text-lg font-semibold text-blue-900">Specializations</h3>
        </div>
        <div className="flex flex-wrap gap-2">
          {trainer.specialization.map((spec, index) => (
            <Badge key={index} variant="info">
              {spec}
            </Badge>
          ))}
        </div>
      </div>

      {/* Certifications */}
      <div className="bg-green-50 rounded-lg p-6 border border-green-200">
        <div className="flex items-center space-x-2 mb-4">
          <CheckCircle className="h-5 w-5 text-green-600" />
          <h3 className="text-lg font-semibold text-green-900">Certifications</h3>
        </div>
        <div className="flex flex-wrap gap-2">
          {trainer.certifications.map((cert, index) => (
            <Badge key={index} variant="success">
              {cert}
            </Badge>
          ))}
        </div>
      </div>

      {/* Assigned Members */}
      <div className="bg-gray-50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Assigned Members</h3>
        {assignedMembers.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {assignedMembers.map((member) => (
              <div key={member.id} className="flex items-center space-x-3 p-3 bg-white rounded-lg border">
                <img
                  src={member.avatar || 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?w=50'}
                  alt={member.name}
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{member.name}</p>
                  <p className="text-sm text-gray-500">{member.email}</p>
                </div>
                <Badge variant={member.isActive ? 'success' : 'danger'} size="sm">
                  {member.isActive ? 'Active' : 'Inactive'}
                </Badge>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <Users className="h-12 w-12 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-500">No members assigned yet</p>
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div className="flex justify-end space-x-3 pt-6 border-t">
        <Button variant="secondary" onClick={onClose}>
          Close
        </Button>
        <Button icon={Edit} onClick={onEdit}>
          Edit Trainer
        </Button>
      </div>
    </div>
  );
};

export default TrainerDetails;